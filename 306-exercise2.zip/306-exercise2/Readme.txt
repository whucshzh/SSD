实验过程：
1.首先在web.xml中配置sevelet
1.然后编辑index.html文件，用表单标签设计实验所需页面，规定为post，action指向配置好的Servelet1

实验过程中遇到的问题：
1.form的action=“Servlet1”一开始无法对应servlet
2.在配置servlet时缺乏相关知识。
3.未能对页面进行更多美化
