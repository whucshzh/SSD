图片位置关系及路径：
public String getImage() {
		if (this.getDirection() == "right") {
			return "./resource/img/CatFish-right.gif";
		}
		if (this.getDirection() == "left") {
			return "./resource/img/CatFish-left.gif";
		}
		if (this.getDirection() == "up") {
			return "./resource/img/CatFish-up.gif";
		}
		if (this.getDirection() == "down") {
			return "./resource/img/CatFish-down.gif";
		}
		return "./resource/img/CatFish-right.gif";
	}
在gerImage方法中定义了catfish和crocodile移动时对应的图片，并设定好了路径。
public String getImage() {
		if (this.getDirection() == "right") {
			return "./resource/img/Crocodile-right.gif";
		}
		if (this.getDirection() == "left") {
			return "./resource/img/Crocodile-left.gif";
		}
		if (this.getDirection() == "up") {
			return "./resource/img/Crocodile-up.gif";
		}
		if (this.getDirection() == "down") {
			return "./resource/img/Crocodile-down.gif";
		}
		return "./resource/img/Crocodile-right.gif";
	}
为实现代码规范所做的工作：
通过书本上和网络上的资料完成了方法的设计，对各种代码规范进行了检查。
方法设计思想：
在完成对象catfish的初始设定时，按照TXT文件所给的要求进行各种属性的初始值设定。
根据要求，
setEnergy给新生成的对象一个初始能量值，大于等于最小能量值，小于等于最大能量值。
isHungry判断catfish是否饥饿，看他能量是否大于两倍的最小能量值
moveToRow对catfish的行间移动做出设定
moveToColumn对catfish的列间运动做出设定
lookForFoodInNeighborhood判断周围的网格里是否存在藻类植物
swimIfPossible如果有藻类植物则游向藻类植物网格，如果没有则随机
eatIfPossible如果到了藻类植物网格，则停留吃食物
liveALittle增加年龄，实行方法等
同理crocodile的设计大同小异，首先也是对新生成对象crocodile的属性初始值进行设定。
与catfish不同的是，crocodile有一个wadeIfPossible的方法，用来设定鳄鱼可以跨越网格



